const express = require('express');
const rutasUsuarios = require('./routes/user.routes');

// Crear aplicación Express
const aplicacion = express();
// Para cambiar: Agregar más configuraciones, ej. CORS

// Analizar cuerpos de solicitud en formato JSON
aplicacion.use(express.json());
// Para cambiar: Agregar otros middleware, ej. registro de solicitudes

// Usar rutas de usuarios para /api/usuarios
aplicacion.use('/api/usuarios', rutasUsuarios);
// Para cambiar: Modificar ruta base o agregar más grupos de rutas

// Manejar rutas no encontradas (404)
aplicacion.use((req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada' });
  // Para cambiar: Personalizar mensaje de error o formato
});

module.exports = aplicacion;