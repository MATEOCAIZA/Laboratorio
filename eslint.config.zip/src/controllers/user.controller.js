// Arreglo en memoria para almacenar usuarios
let usuarios = [];

// Obtener todos los usuarios
// Devuelve el arreglo completo de usuarios en formato JSON
function obtenerTodosUsuarios(req, res) {
  res.json(usuarios); // Enviar arreglo de usuarios como respuesta
  // Para cambiar: Modificar formato de respuesta si se necesita, ej. agregar metadatos
}

// Obtener un usuario por ID
// Toma un ID de la URL y devuelve el usuario correspondiente
function obtenerUsuarioPorId(req, res) {
  const id = parseInt(req.params.id); // Convertir ID a número
  // Para cambiar: Agregar más validaciones para el ID si es necesario
  if (isNaN(id)) {
    return res.status(400).json({ error: 'ID inválido' }); // Error si ID no es número
  }

  const usuario = usuarios.find(u => u.id === id); // Buscar usuario por ID
  // Para cambiar: Modificar cómo se busca el usuario, ej. usar otra clave
  if (!usuario) {
    return res.status(404).json({ error: 'Usuario no encontrado' }); // Error si no se encuentra
  }

  res.json(usuario); // Enviar usuario encontrado como respuesta
  // Para cambiar: Ajustar formato de respuesta, ej. devolver campos específicos
}

// Crear un nuevo usuario
// Espera usuario y precio en el cuerpo de la solicitud
function crearUsuario(req, res) {
  // Verificar si el cuerpo de la solicitud existe
  if (!req.body) {
    return res.status(400).json({ error: 'Usuario y Precio son requeridos' });
    // Para cambiar: Agregar mensajes de error más específicos
  }

  const { usuario, precio } = req.body; // Obtener usuario y precio
  // Para cambiar: Agregar más campos al objeto usuario si es necesario

  // Validación simple: usuario y precio deben ser cadenas no vacías
  if (!usuario || !precio || typeof usuario !== 'string' || typeof precio !== 'string') {
    return res.status(400).json({ error: 'Usuario y Precio deben ser cadenas no vacías' });
    // Para cambiar: Agregar más reglas de validación, ej. formato de precio
  }

  const nuevoUsuario = {
    id: Date.now(), // Usar marca de tiempo como ID único
    usuario: usuario.trim(), // Eliminar espacios
    precio: precio.trim() // Eliminar espacios
    // Para cambiar: Modificar generación de ID o agregar más campos
  };

  usuarios.push(nuevoUsuario); // Agregar usuario al arreglo
  // Para cambiar: Usar otro método de almacenamiento, ej. base de datos
  res.status(201).json(nuevoUsuario); // Enviar usuario creado como respuesta
  // Para cambiar: Ajustar respuesta, ej. devolver solo ID
}

// Eliminar un usuario por ID
// Elimina un usuario con el ID dado
function eliminarUsuarioPorId(req, res) {
  const id = parseInt(req.params.id); // Convertir ID a número
  // Para cambiar: Agregar más validaciones para el ID si es necesario
  if (isNaN(id)) {
    return res.status(400).json({ error: 'ID inválido' });
  }

  const indiceUsuario = usuarios.findIndex(u => u.id === id); // Buscar índice del usuario
  // Para cambiar: Modificar cómo se busca el usuario
  if (indiceUsuario === -1) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }

  usuarios.splice(indiceUsuario, 1); // Eliminar usuario del arreglo
  // Para cambiar: Agregar registro o efectos secundarios
  res.status(204).send(); // Enviar respuesta sin contenido
  // Para cambiar: Devolver datos del usuario eliminado si es necesario
}

// Reiniciar arreglo de usuarios para pruebas
// Limpia la base de datos en memoria
function reiniciarUsuarios() {
  usuarios = [];
  // Para cambiar: Agregar lógica para reiniciar otros datos si es necesario
}

module.exports = { obtenerTodosUsuarios, obtenerUsuarioPorId, crearUsuario, eliminarUsuarioPorId, usuarios, reiniciarUsuarios };