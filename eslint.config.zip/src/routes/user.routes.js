const express = require('express');
const { obtenerTodosUsuarios, obtenerUsuarioPorId, crearUsuario, eliminarUsuarioPorId } = require('../controllers/user.controller');

// Crear un nuevo enrutador para rutas de usuarios
const enrutador = express.Router();
// Para cambiar: Agregar middleware para autenticación si es necesario

// GET para obtener todos los usuarios
enrutador.get('/', obtenerTodosUsuarios);
// Para cambiar: Agregar parámetros de consulta para filtrar

// GET para obtener un usuario por ID
enrutador.get('/:id', obtenerUsuarioPorId);
// Para cambiar: Modificar el patrón de URL si es necesario

// POST para crear un nuevo usuario
enrutador.post('/', crearUsuario);
// Para cambiar: Agregar middleware para validación de solicitudes

// DELETE para eliminar un usuario por ID
enrutador.delete('/:id', eliminarUsuarioPorId);
// Para cambiar: Agregar paso de confirmación antes de eliminar

module.exports = enrutador;