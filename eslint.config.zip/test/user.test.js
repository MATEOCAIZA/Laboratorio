const request = require('supertest');
const aplicacion = require('../src/app');

// Suite de pruebas para la API de usuarios
describe('API de Usuarios', () => {
  // Reiniciar usuarios antes de cada prueba
  beforeEach(async () => {
    const controladorUsuarios = require('../src/controllers/user.controller');
    controladorUsuarios.reiniciarUsuarios(); // Limpiar base de datos en memoria
    // Para cambiar: Agregar datos iniciales para pruebas si es necesario
  });

  // Pruebas para GET /api/usuarios - Obtener todos los usuarios
  test('debería devolver lista vacía si no hay usuarios', async () => {
    const res = await request(aplicacion).get('/api/usuarios');
    expect(res.statusCode).toBe(200);
    expect(res.body).toEqual([]); // Esperar arreglo vacío
    // Para cambiar: Modificar formato de respuesta esperado
  });

  test('debería devolver dos usuarios en orden', async () => {
    await request(aplicacion).post('/api/usuarios').send({ usuario: 'Juan', precio: '50' });
    await request(aplicacion).post('/api/usuarios').send({ usuario: 'Ana', precio: '75' });
    const res = await request(aplicacion).get('/api/usuarios');
    expect(res.statusCode).toBe(200);
    expect(res.body.length).toBe(2);
    expect(res.body[0].usuario).toBe('Juan');
    expect(res.body[1].precio).toBe('75');
    // Para cambiar: Probar con diferentes usuarios o precios
  });

  // Pruebas para POST /api/usuarios - Agregar usuario
  test('debería crear usuario correctamente', async () => {
    const res = await request(aplicacion).post('/api/usuarios').send({ usuario: 'Pedro', precio: '100' });
    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty('id');
    expect(res.body.usuario).toBe('Pedro');
    expect(res.body.precio).toBe('100');
    // Para cambiar: Probar con otros datos de usuario o precio
  });

  test('debería fallar sin precio', async () => {
    const res = await request(aplicacion).post('/api/usuarios').send({ usuario: 'María' });
    expect(res.statusCode).toBe(400);
    expect(res.body.error).toBe('Usuario y Precio deben ser cadenas no vacías');
    // Para cambiar: Modificar mensaje de error o datos de prueba
  });

  // Pruebas para GET /api/usuarios/:id - Obtener usuario por ID
  test('debería obtener usuario por ID', async () => {
    const postRes = await request(aplicacion).post('/api/usuarios').send({ usuario: 'Luis', precio: '25' });
    const id = postRes.body.id;
    const res = await request(aplicacion).get(`/api/usuarios/${id}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.usuario).toBe('Luis');
    expect(res.body.precio).toBe('25');
    // Para cambiar: Probar con otros datos de usuario o precio
  });

  // Pruebas para DELETE /api/usuarios/:id - Eliminar usuario por ID
  test('debería eliminar usuario por ID', async () => {
    const postRes = await request(aplicacion).post('/api/usuarios').send({ usuario: 'Sofía', precio: '200' });
    const id = postRes.body.id;
    const res = await request(aplicacion).delete(`/api/usuarios/${id}`);
    expect(res.statusCode).toBe(204);
    const getRes = await request(aplicacion).get('/api/usuarios');
    expect(getRes.body.length).toBe(0);
    // Para cambiar: Probar con otros datos de usuario o verificar eliminación de otra manera
  });
});