const js = require('@eslint/js');

// Configuración de ESLint para archivos JavaScript
module.exports = [
  {
    files: ['src/**/*.js'], // Aplicar a todos los archivos .js en src
    // Para cambiar: Modificar patrones de archivos
    languageOptions: {
      ecmaVersion: 2021, // Usar JavaScript moderno
      sourceType: 'commonjs', // Usar módulos CommonJS
      // Para cambiar: Cambiar a 'module' para módulos ES
    },
    rules: {
      ...js.configs.recommended.rules, // Usar reglas recomendadas de ESLint
      'no-console': ['error'], // Prohibir console.log
      'no-unused-vars': ['error'], // Prohibir variables no usadas
      'eqeqeq': ['error', 'always'], // Exigir === en lugar de ==
      'no-undef': ['error'], // Prohibir variables no definidas
      'curly': ['error', 'all'], // Exigir llaves para bloques de control
      // Para cambiar: Agregar o modificar reglas de estilo
    },
  },
];